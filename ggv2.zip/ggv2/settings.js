const settings = {
  ownerName: 'Private DDoS', // Ganti dengan nama owner lu
  botToken: '7991634233:AAFXHFw8L-j8GsS-K7Sf363aQKgdd439HWc', // Ganti dengan token bot Telegram lu
  owner: '7699437040', //OWNER user id
};

module.exports = settings;
